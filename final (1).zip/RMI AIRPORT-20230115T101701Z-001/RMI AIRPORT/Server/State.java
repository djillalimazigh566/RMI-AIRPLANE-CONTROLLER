package Server;

public enum State {
	Active,
	Standby,
	Idle,
	New,
	Broken
};