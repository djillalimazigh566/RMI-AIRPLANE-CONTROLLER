package Server;

public enum Etat{
	Normal,
	Catastrophe,
	Danger 
};